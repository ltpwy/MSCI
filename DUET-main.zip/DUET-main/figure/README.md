Dir for figures.
